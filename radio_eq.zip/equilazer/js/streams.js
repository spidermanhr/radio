// Ucitavanje streamova iz streams.json
let streams = [];

fetch('js/streams.json')  // Zamijenite s ispravnim putem do JSON datoteke
  .then(response => response.json())
  .then(data => {
    // Filtriraj streamove gdje je prikazi !== "N"
    streams = data.streams.filter(stream => stream.prikazi !== "N");

    // Postavljanje default streama prilikom ucitavanja stranice
    setDefaultStream();
  })
  .catch(error => {
    console.error("Greška prilikom učitavanja streamova:", error);
  });

// Funkcija za postavljanje default streama
function setDefaultStream() {
  // Postavi Yammat kao default ako postoji
  const defaultStream = streams.find(stream => stream.name === 'Yammat');
  if (defaultStream) {
    document.getElementById('radioSource').src = defaultStream.stream_url;
    document.getElementById('radioSelect').value = defaultStream.name.toLowerCase();
    const player = document.getElementById('radioPlayer');
    player.load();
    player.play();
  }
}

// Funkcija za promjenu streama na temelju odabira u select boxu
function changeRadioStream() {
  // Dohvati odabrani radio iz select box-a
  const selectedRadio = document.getElementById('radioSelect').value;
  
  // Pronađi stream prema odabranom imenu
  const stream = streams.find(radio => radio.name.toLowerCase() === selectedRadio.toLowerCase());

  if (stream) {
    // Postavi izvor streama
    const radioPlayer = document.getElementById('radioPlayer');
    const radioSource = document.getElementById('radioSource');
    radioSource.src = stream.stream_url;
    radioPlayer.load();  // Ponovno učitaj player
    radioPlayer.play();  // Pokreni stream

    // Ispis za debug
    console.log('Odabrani radio: ', stream.name);
    console.log('Stream URL: ', stream.stream_url);
    console.log('Song URL: ', stream.stream_song_url);
    console.log('PHP Script: ', stream.php_script);
  } else {
    console.error("Stream za odabrani radio nije pronađen.");
  }
}
