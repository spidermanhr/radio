const bassControl = document.getElementById('bassControl');
const trebleControl = document.getElementById('trebleControl');
const balanceControl = document.getElementById('balanceControl');
const resetButton = document.getElementById('resetControls');

bassControl.addEventListener('input', () => {
  bassFilter.gain.value = bassControl.value;
});

trebleControl.addEventListener('input', () => {
  trebleFilter.gain.value = trebleControl.value;
});

balanceControl.addEventListener('input', () => {
  stereoPanner.pan.value = parseFloat(balanceControl.value);
});

resetButton.addEventListener('click', () => {
  bassControl.value = 0;
  trebleControl.value = 0;
  balanceControl.value = 0;

  bassFilter.gain.value = 0;
  trebleFilter.gain.value = 0;
  stereoPanner.pan.value = 0;
});
