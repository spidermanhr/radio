const canvas = document.getElementById('visualizer');
const ctx = canvas.getContext('2d');
let audioContext, analyser, source, bassFilter, trebleFilter, stereoPanner;

function initializeAudioContext() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 512;

    source = audioContext.createMediaElementSource(audio);
    bassFilter = audioContext.createBiquadFilter();
    bassFilter.type = 'lowshelf';
    bassFilter.frequency.value = 200;

    trebleFilter = audioContext.createBiquadFilter();
    trebleFilter.type = 'highshelf';
    trebleFilter.frequency.value = 3000;

    stereoPanner = audioContext.createStereoPanner();
    source.connect(bassFilter);
    bassFilter.connect(trebleFilter);
    trebleFilter.connect(stereoPanner);
    stereoPanner.connect(analyser);
    analyser.connect(audioContext.destination);

    draw();
  }
}

// refleksija gore - dolje
/*
function draw() {
  requestAnimationFrame(draw);
  const bufferLength = analyser.frequencyBinCount;
  const dataArray = new Uint8Array(bufferLength);
  analyser.getByteFrequencyData(dataArray);

  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const barWidth = (canvas.width / bufferLength) * 1.5;
  let x = 0;

  const centerY = canvas.height / 2;
  const gap = 1;

  ctx.fillStyle = '#000';
  ctx.fillRect(0, centerY - gap / 2, canvas.width, gap);

  for (let i = 0; i < bufferLength; i++) {
    const barHeight = dataArray[i];
    ctx.fillStyle = `rgb(${barHeight}, ${255 - barHeight}, ${barHeight / 2})`;
    ctx.fillRect(x, centerY - barHeight / 2, barWidth, barHeight / 2);
    ctx.fillRect(x, centerY, barWidth, barHeight / 2);
    x += barWidth + 1;
  }
}
*/

// nema refleksije
let lastDrawTime = 0;
const drawInterval = 30; // Vrijeme između svakog crtanja u milisekundama

function draw() {
  const now = Date.now();
  if (now - lastDrawTime >= drawInterval) {
    lastDrawTime = now;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyser.getByteFrequencyData(dataArray);

    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Postavke veličine mreže
    const barWidth = (canvas.width / bufferLength) * 1.5; // Širina jednog stupca
    const segmentHeight = 5; // Visina jednog pravokutnika u stupcu

    // Crtanje mreže
    ctx.strokeStyle = '#333'; // Boja linija mreže
    ctx.lineWidth = 1;

    for (let x = 0; x <= canvas.width; x += barWidth + 1) {
      for (let y = 0; y <= canvas.height; y += segmentHeight) {
        ctx.strokeRect(x, y, barWidth, segmentHeight);
      }
    }

    // Crtanje animiranih stupaca (pikselizirani stupci)
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
      const barHeight = dataArray[i];
      const numSegments = Math.floor(barHeight / segmentHeight); // Broj segmenata za trenutni stupac

      for (let j = 0; j < numSegments; j++) {
        ctx.fillStyle = `rgb(${barHeight}, ${255 - barHeight}, ${barHeight / 2})`;
        ctx.fillRect(x, canvas.height - (j + 1) * segmentHeight, barWidth, segmentHeight - 1); // -1 za malo razmaka
      }

      x += barWidth + 1; // Dodaj razmak između stupaca
    }
  }
  requestAnimationFrame(draw); // Nastavljamo s animacijom
}







function resizeCanvas() {
  canvas.width = window.innerWidth;
  /*canvas.height = window.innerHeight;*/
  canvas.height = 300; // Ovdje postavite željenu visinu
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

audio.addEventListener('play', () => {
  initializeAudioContext();
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }
});
