
  var user = "test";
  var domain = "haustor.eu";
  var mailto = "mailto:" + user + "@" + domain;
  document.write('<a href="' + mailto + '">' + user + '@' + domain + '</a>');
