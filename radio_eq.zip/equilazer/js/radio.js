  document.addEventListener('DOMContentLoaded', () => {
    const defaultStationName = 'yammat'; // Naziv stanice koja se prvo učitava
    changeStation(defaultStationName); // Promijeni stanicu na zadanu
  });
