if ('Notification' in window && Notification.permission !== 'granted') {
  Notification.requestPermission().then((permission) => {
    console.log(permission === 'granted' ? 'Notification permission granted.' : 'Notification permission denied.');
  });
}

let previousSong = '';
let currentStream = null; // Inicijaliziraj kao null

const audio = document.getElementById('radioPlayer');

function changeRadioStream() {
  const radioSelect = document.getElementById('radioSelect');
  const stationName = radioSelect.value;  // Dohvati odabranu vrijednost
  changeStation(stationName);  // Promjeni stanicu
}

// Funkcija za učitavanje stream podataka i promjenu stanice
function changeStation(stationName) {

  const xhr = new XMLHttpRequest();
  xhr.open('GET', 'js/streams.json', true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const streamsData = JSON.parse(xhr.responseText);
      const stream = streamsData.streams.find(s => s.name === stationName);

      if (stream) {
        currentStream = stream; // Postavi currentStream
        console.log('Odabrana stanica:', currentStream);

        // Postavi ispravan URL za audio player
        const radioSource = document.getElementById('radioSource');
        const audio = document.getElementById('radioPlayer');
        radioSource.src = currentStream.stream_url; // Postavi URL streama
        console.log('Eywa2:', radioSource.src);
        audio.load(); // Ponovno učitaj audio player s novim URL-om
        
                // Automatski pokreni reprodukciju
        audio.play()
          .then(() => {
            console.log('Reprodukcija započela.', radioSource.src);
          })
          .catch(error => {
            console.error('Greška pri pokušaju pokretanja reprodukcije:', error);
          });

        fetchCurrentSong(radioSource.src); // Započni dohvat pjesme
      } else {
        console.error('Stanica nije pronađena:', stationName);
        currentStream = null;
      }
    }
  };
  xhr.send();
}

// Funkcija za dohvat trenutne pjesme
function fetchCurrentSong(streamUrl) {
  if (!streamUrl) {
    console.error('URL streama nije dostupan.');
    return;
  }
  console.log('Eywa', streamUrl);

  const xhr = new XMLHttpRequest();
  xhr.open('GET', `php/getStreamSong.php?stream=${encodeURIComponent(streamUrl)}`, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      const currentSong = xhr.responseText.trim();

      // Ako nema pjesme ili je prazan string
      if (!currentSong) {
        document.getElementById('currentSong').innerHTML = 'Nema podataka';
        document.getElementById('albumImage').src = 'image/lp.jpg'; // Postavi zadanu sliku
        document.getElementById('albumName').innerHTML = ''; // Očisti naziv albuma
        document.getElementById('releaseYear').textContent = ''; // Očisti godinu izdanja
        previousSong = ''; // Resetiraj prethodnu pjesmu
        return;
      }

      // Ako je pjesma promijenjena i audio nije pauziran
      if (currentSong !== previousSong && !audio.paused) {
        document.getElementById('currentSong').innerHTML = `${currentSong}`;

        // Parsiranje izvođača i naziva pjesme iz currentSong
        const [artist, song] = currentSong.split(' - '); // Pretpostavljamo format "Izvođač - Pjesma"

        // Dohvati podatke o albumu
        fetchAlbumImage(artist, song);

        previousSong = currentSong;
      }
    }
  };
  xhr.send();
}


// Funkcija za dohvat podataka o pjesmi i prikazivanje albuma
function fetchAlbumImage(artist, song) {
  fetch(`https://itunes.apple.com/search?term=${song}+${artist}&entity=song`)
    .then(response => response.json())
    .then(data => {
      let albumImage = 'image/lp.jpg'; // Zadana slika u slučaju da nema albuma
      let albumName = ''; // Zadani naziv albuma
      let releaseYear = ''; // Zadana godina izdanja

      if (data.results.length > 0) {
        albumImage = data.results[0].artworkUrl100 || albumImage; // Slika albuma ili zadana slika
        albumName = data.results[0].collectionName || ''; // Naziv albuma ili prazan
        releaseYear = data.results[0].releaseDate?.split('-')[0] || ''; // Godina izdanja ili prazan
      } else {
        console.log("Nema podataka o albumu za ovu pjesmu. Postavljam zadanu sliku.");
      }

      // Postavi sliku albuma
      document.getElementById('albumImage').src = albumImage;
      document.getElementById('albumName').innerHTML = albumName ? `Album: ${albumName}` : ''; // Prikaži naziv albuma ili ništa
      document.getElementById('releaseYear').textContent = releaseYear ? `Godina: ${releaseYear}` : ''; // Prikaži godinu ili ništa

      // Pošaljite sliku albuma u funkciju za notifikacije
      showNotification(song, artist, albumImage);
    })
    .catch(error => {
      console.error('Error fetching album image:', error);
      // Ako dođe do greške, postavi zadanu sliku i očisti polja
      document.getElementById('albumImage').src = 'image/lp.jpg';
      document.getElementById('albumName').innerHTML = '';
      document.getElementById('releaseYear').textContent = '';
      showNotification(song, artist, 'image/lp.jpg'); // Notifikacija s zadatom slikom
    });
}

// Funkcija za prikaz notifikacije
function showNotification(song, artist, albumImage) {
  if ('Notification' in window) {
    if (Notification.permission === 'granted') {
      new Notification('Trenutna pjesma', {
        body: `${artist} - ${song}`,
        icon: albumImage  // Dodajte sliku albuma kao ikonu
      });
    } else if (Notification.permission === 'default') {
      console.log('Notifikacije nisu dopuštene, čekam korisnikov odgovor...');
    } else {
      console.log('Notifikacije nisu dopuštene.');
    }
  }
}

// Kada se audio player pokrene, prikaži album
/*
audio.addEventListener('play', () => {
  initializeAudioContext();
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }

  // Pozovi funkciju za dohvat trenutne pjesme
  fetchCurrentSong(streamUrl);
});

setInterval(fetchCurrentSong(streamUrl), 10000);
fetchCurrentSong(streamUrl);
*/
audio.addEventListener('play', () => {
  if (currentStream) {
    fetchCurrentSong(currentStream.stream_url);
  } else {
    console.error('Nema aktivnog streama za dohvat pjesme.');
  }
});

// Periodično dohvaćanje trenutne pjesme
setInterval(() => {
  if (currentStream) {
    fetchCurrentSong(currentStream.stream_url); // Koristi trenutni stream URL
  } else {
    console.error('Stream URL nije dostupan.');
  }
}, 10000);

// Inicijalni poziv za dohvat trenutne pjesme
if (currentStream) {
  fetchCurrentSong(currentStream.stream_url);
} else {
  console.error('Stream URL nije dostupan pri inicijalizaciji.');
}
