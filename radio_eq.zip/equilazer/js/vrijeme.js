    // Parsiranje XML podataka iz PHP-a
    const parser = new DOMParser();
    const xml = parser.parseFromString(xmlData, 'application/xml');

    // Funkcija za izračun udaljenosti između dvije GPS točke (Haversine formula)
    function izracunajUdaljenost(lat1, lon1, lat2, lon2) {
      const R = 6371; // Polumjer Zemlje u kilometrima
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLon = (lon2 - lon1) * Math.PI / 180;
      const a = 
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c; // Udaljenost u kilometrima
    }

    // Odabir odgovarajuće ikone na temelju opisa vremena
    function dohvatiIkonu(opis) {
    /*
      if (opis.includes('sunčano')) return '<i class="wi wi-day-sunny"></i>';
      if (opis.includes('kiša')) return '<i class="wi wi-rain"></i>';
      if (opis.includes('snijeg')) return '<i class="wi wi-snow"></i>';
      if (opis.includes('magla')) return '<i class="wi wi-fog"></i>';
      if (opis.includes('pretežno vedro')) return '<i class="wi wi-fog"></i>';
      return '<i class="wi wi-na"></i>'; // Zadana ikona
*/
      if (opis.includes('1')) return '<img width="40" src="image/vrijeme/1.svg">';
      if (opis.includes('2')) return '<img width="40" src="image/vrijeme/2.svg">';
      if (opis.includes('3')) return '<img width="40" src="image/vrijeme/3.svg">';
      if (opis.includes('4')) return '<img width="40" src="image/vrijeme/4.svg">';
      if (opis.includes('5')) return '<img width="40" src="image/vrijeme/5.svg">';
      if (opis.includes('6')) return '<img width="40" src="image/vrijeme/6.svg">';
      if (opis.includes('7')) return '<img width="40" src="image/vrijeme/7.svg">';
      if (opis.includes('8')) return '<img width="40" src="image/vrijeme/8.svg">';
      if (opis.includes('9')) return '<img swidth="40" rc="image/vrijeme/9.svg">';
      if (opis.includes('10')) return '<img swidth="40" rc="image/vrijeme/10.svg">';
      if (opis.includes('11')) return '<img swidth="40" rc="image/vrijeme/11.svg">';
      if (opis.includes('13')) return '<img swidth="40" rc="image/vrijeme/12.svg">';
      if (opis.includes('13')) return '<img swidth="40" rc="image/vrijeme/13.svg">';
      if (opis.includes('14')) return '<img swidth="40" rc="image/vrijeme/14.svg">';
      if (opis.includes('15')) return '<img swidth="40" rc="image/vrijeme/15.svg">';
      return '<i class="wi wi-na"></i>'; // Zadana ikona
      /**/
    }

    // Inicijalizacija i prikaz podataka
    function inicijaliziraj() {
      const gradovi = xml.getElementsByTagName('Grad');
      const gradSelect = document.getElementById('gradSelect');
      const podaciDiv = document.getElementById('podaci');
      const lokacijaPodaci = document.getElementById('lokacijaPodaci');

      // Popunjavanje opcija u select elementu
      Array.from(gradovi).forEach((grad, index) => {
        const gradIme = grad.getElementsByTagName('GradIme')[0].textContent.trim();
        const option = document.createElement('option');
        option.value = index;
        option.textContent = gradIme;
        gradSelect.appendChild(option);
      });

      // Prikaz podataka za odabrani grad
      gradSelect.addEventListener('change', () => {
        prikaziPodatke(gradSelect.value);
      });

      // Automatski odabir prvog grada
      gradSelect.value = 0;
      gradSelect.dispatchEvent(new Event('change'));

      // Dohvaćanje trenutne lokacije korisnika
      if (navigator.geolocation) {
        //lokacijaPodaci.innerHTML = '<p>Dohvaćanje lokacije, molimo pričekajte...</p>';
        navigator.geolocation.getCurrentPosition((position) => {
          const userLat = position.coords.latitude;
          const userLon = position.coords.longitude;

          let najbliziGrad = null;
          let najmanjaUdaljenost = Infinity;

          Array.from(gradovi).forEach((grad, index) => {
            const lat = parseFloat(grad.getElementsByTagName('Lat')[0].textContent.trim());
            const lon = parseFloat(grad.getElementsByTagName('Lon')[0].textContent.trim());
            const udaljenost = izracunajUdaljenost(userLat, userLon, lat, lon);

            if (udaljenost < najmanjaUdaljenost) {
              najmanjaUdaljenost = udaljenost;
              najbliziGrad = index;
            }
          });

          // Automatski odabir najbližeg grada
          if (najbliziGrad !== null) {
            gradSelect.value = najbliziGrad;
            gradSelect.dispatchEvent(new Event('change'));

            /*
            lokacijaPodaci.innerHTML = `
              <h4>Vaša lokacija</h4>
              <p><strong>Latituda:</strong> ${userLat.toFixed(2)}</p>
              <p><strong>Longituda:</strong> ${userLon.toFixed(2)}</p>
              <p><strong>Najbliži grad:</strong> ${gradovi[najbliziGrad].getElementsByTagName('GradIme')[0].textContent.trim()}</p>
              <p><strong>Udaljenost:</strong> ${najmanjaUdaljenost.toFixed(2)} km</p>
            `;
            */
          }
        }, (error) => {
          lokacijaPodaci.innerHTML = '<p>Geolokacija nije uspjela ili je isteklo vrijeme za dobivanje lokacije.</p>';
        }, { timeout: 10000 }); // Timeout postavljen na 5 sekundi
      } else {
        lokacijaPodaci.innerHTML = '<p>Geolokacija nije podržana u vašem pregledniku.</p>';
      }
    }

    function prikaziPodatke(index) {
      const gradovi = xml.getElementsByTagName('Grad');
      const datumTermin = xml.getElementsByTagName('DatumTermin')[0];
      const datum = datumTermin.getElementsByTagName('Datum')[0].textContent.trim();
      const termin = datumTermin.getElementsByTagName('Termin')[0].textContent.trim();

      const odabraniGrad = gradovi[index];
      const gradIme = odabraniGrad.getElementsByTagName('GradIme')[0].textContent.trim();
      const temp = odabraniGrad.getElementsByTagName('Temp')[0].textContent.trim();
      const vlaga = odabraniGrad.getElementsByTagName('Vlaga')[0].textContent.trim();
      const tlak = odabraniGrad.getElementsByTagName('Tlak')[0].textContent.trim();
      const smjerVjetra = odabraniGrad.getElementsByTagName('VjetarSmjer')[0].textContent.trim();
      const brzinaVjetra = odabraniGrad.getElementsByTagName('VjetarBrzina')[0].textContent.trim();
      const vrijemeOpis = odabraniGrad.getElementsByTagName('Vrijeme')[0].textContent.trim();
      const vrijemeIkona = odabraniGrad.getElementsByTagName('VrijemeZnak')[0].textContent.trim();

      const ikonaHTML = dohvatiIkonu(vrijemeIkona);
      //const ikonaHTML = dohvatiIkonu(vrijemeOpis);
      
      const podaciDiv = document.getElementById('podaci');
      /*
      podaciDiv.innerHTML = `
        <h4>${gradIme}</h4>
        <strong>Temperatura:</strong> ${temp} &#8451;<br>
        <strong>Vlaga:</strong> ${vlaga}%<br>
        <strong>Tlak:</strong> ${tlak} hPa<br>
        <strong>Smjer vjetra:</strong> ${smjerVjetra}<br>
        <strong>Brzina vjetra:</strong> ${brzinaVjetra} km/h<br>
        <strong>Vrijeme:</strong> ${vrijemeOpis} ${ikonaHTML}
      `;
      */
      podaciDiv.innerHTML = `
        <div class="podaci-container">
          <div class="tekstualni-podaci">
            <h4>${gradIme}</h4>
            Datum - ${datum}.; Sat: ${termin}:00
            <strong>Temperatura:</strong> ${temp} &#8451;<br>
            <strong>Vlaga:</strong> ${vlaga}%<br>
            <strong>Tlak:</strong> ${tlak} hPa<br>
            <strong>Smjer vjetra:</strong> ${smjerVjetra}<br>
            <strong>Brzina vjetra:</strong> ${brzinaVjetra} km/h<br>
            <strong>Vrijeme:</strong> ${vrijemeOpis}
          </div>
          <div class="ikona">
            ${ikonaHTML}
          </div>
        </div>
      `;
    }

    // Pokretanje inicijalizacije
    //inicijaliziraj();

    // Automatsko osvježavanje skripte svakih puni sat + 10 minuta
    function pokreniOsvježavanje() {
      console.log("Skripta osvježena u:", new Date().toLocaleTimeString());
      inicijaliziraj();
    }

    function izracunajVrijemeDoSljedecegIntervala() {
      const sada = new Date();
      const trenutniSati = sada.getHours();
      const trenutneMinute = sada.getMinutes();

      let ciljSati = trenutniSati;
      let ciljMinute = 10;

      if (trenutneMinute >= 10) {
        ciljSati = trenutniSati + 1;
        if (ciljSati === 24) ciljSati = 0;
      }

      const ciljVrijeme = new Date();
      ciljVrijeme.setHours(ciljSati, ciljMinute, 0, 0);

      return ciljVrijeme.getTime() - sada.getTime();
    }

    setTimeout(() => {
      pokreniOsvježavanje();
      setInterval(pokreniOsvježavanje, 70 * 60 * 1000);
    }, izracunajVrijemeDoSljedecegIntervala());

    // Pokretanje inicijalizacije
    inicijaliziraj();