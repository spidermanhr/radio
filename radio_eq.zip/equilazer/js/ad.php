<?php
define('FILE_PATH', 'streams.json');

// Funkcije za rad s JSON-om
function loadStreams() {
    if (!file_exists(FILE_PATH)) {
        return ['streams' => []];
    }
    $json = file_get_contents(FILE_PATH);
    return json_decode($json, true);
}

function saveStreams($data) {
    file_put_contents(FILE_PATH, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Rukovanje zahtjevima
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = loadStreams();

    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $data['streams'][] = [
                    "name" => $_POST['name'],
                    "stream_url" => $_POST['stream_url'],
                    "stream_song_url" => $_POST['stream_song_url'],
                    "php_script" => $_POST['php_script'],
                    "prikazi" => $_POST['prikazi']
                ];
                break;

            case 'update':
                foreach ($data['streams'] as &$stream) {
                    if ($stream['name'] === $_POST['original_name']) {
                        $stream['name'] = $_POST['name'];
                        $stream['stream_url'] = $_POST['stream_url'];
                        $stream['stream_song_url'] = $_POST['stream_song_url'];
                        $stream['php_script'] = $_POST['php_script'];
                        $stream['prikazi'] = $_POST['prikazi'];
                        break;
                    }
                }
                break;

            case 'delete':
                $data['streams'] = array_filter($data['streams'], fn($stream) => $stream['name'] !== $_POST['name']);
                break;
        }
    }

    saveStreams($data);
    header('Location: ad.php');
    exit;
}

$streams = loadStreams();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Radio Streams CRUD</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"], select {
            width: calc(100% - 10px);
            padding: 5px;
            margin-bottom: 10px;
        }
        button {
            padding: 5px 10px;
            margin-right: 5px;
        }
    </style>
</head>
<body>

<h1>Radio Streams CRUD</h1>

<!-- Forma za dodavanje novog streama -->
<form method="POST" action="ad.php">
    <h3>Dodaj novi stream</h3>
    <input type="hidden" name="action" value="add">
    <input type="text" name="name" placeholder="Ime" required>
    <input type="text" name="stream_url" placeholder="Stream URL" required>
    <input type="text" name="stream_song_url" placeholder="Stream Song URL" required>
    <input type="text" name="php_script" placeholder="PHP Skripta" required>
    <label for="prikazi">Prikazuj:</label>
    <select name="prikazi" id="prikazi">
        <option value="D">Da</option>
        <option value="N">Ne</option>
    </select>
    <button type="submit">Dodaj</button>
</form>

<!-- Popis svih streamova -->
<h3>Popis streamova</h3>
<table>
    <thead>
        <tr>
            <th>Ime</th>
            <th>Stream URL</th>
            <th>Stream Song URL</th>
            <th>PHP Skripta</th>
            <th>Prikazi</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($streams['streams'] as $stream): ?>
        <tr>
            <td><?= htmlspecialchars($stream['name']) ?></td>
            <td><?= htmlspecialchars($stream['stream_url']) ?></td>
            <td><?= htmlspecialchars($stream['stream_song_url']) ?></td>
            <td><?= htmlspecialchars($stream['php_script']) ?></td>
            <td><?= htmlspecialchars($stream['prikazi']) ?></td>
            <td>
                <!-- Forma za brisanje -->
                <form method="POST" action="ad.php" style="display:inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="name" value="<?= htmlspecialchars($stream['name']) ?>">
                    <button type="submit">Obriši</button>
                </form>
                <!-- Forma za ažuriranje -->
                <form method="POST" action="ad.php" style="display:inline;">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="original_name" value="<?= htmlspecialchars($stream['name']) ?>">
                    <input type="text" name="name" value="<?= htmlspecialchars($stream['name']) ?>" required>
                    <input type="text" name="stream_url" value="<?= htmlspecialchars($stream['stream_url']) ?>" required>
                    <input type="text" name="stream_song_url" value="<?= htmlspecialchars($stream['stream_song_url']) ?>" required>
                    <input type="text" name="php_script" value="<?= htmlspecialchars($stream['php_script']) ?>" required>
                    <select name="prikazi">
                        <option value="D" <?= $stream['prikazi'] === 'D' ? 'selected' : '' ?>>Da</option>
                        <option value="N" <?= $stream['prikazi'] === 'N' ? 'selected' : '' ?>>Ne</option>
                    </select>
                    <button type="submit">Ažuriraj</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>

