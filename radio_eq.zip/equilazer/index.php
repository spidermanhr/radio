<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Radio Player</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato&family=Roboto&family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/weather-icons/2.0.10/css/weather-icons.min.css">
  </head>
  <body>
  <?php
    // Dohvaćanje XML podataka s URL-a
    $xml_url = 'https://vrijeme.hr/hrvatska_n.xml';
    $xml_data = file_get_contents($xml_url);
    echo "<script>const xmlData = `" . addslashes($xml_data) . "`;</script>";
  ?>
  <nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Radio player</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarColor01">
        <form class="d-flex">
          <select id="gradSelect" class="form-select">
            <!-- Opcije će se automatski popuniti -->
          </select>
        </form>
        <!--<span id="currentStation" class="navbar-text text-white ms-3">Nijedna postaja nije odabrana</span>-->
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#aboutModal">O nama</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#changelogModal">Promjene</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#contactModal">Kontakt</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  
  <!-- Glavni sadržaj -->
  <div class="container-fluid main-content">
    
    <div class="row">
      
      <div class="col-md-3">
        <div class="card text-white bg-primary">
          <div class="card-header">Radio stanica</div>
          <div class="card-body">
            <audio id="radioPlayer" controls crossorigin="anonymous">
            <source id="radioSource" src="sample/test_speaker.m4a" type="audio/mpeg">
            Vaš preglednik ne podržava audio element.
            </audio>
            <select id="radioSelect" class="form-select w-100" onchange="changeStation(this.value)" size="6">
              <!--<option value="izaberite" selected>Izaberite</option>-->
              <option value="Yammat_FM">Yammat FM</option>
              <option value="Radio_Crash">Radio Crash</option>
              <option value="Italo_Disco_Net">Italo Disco Net</option>
              <option value="Radio_Sljeme">Radio Sljeme</option>
              <option value="Radio_Student">Radio Student</option>
              <option value="HR_1_program">HR 1 program</option>
              <option value="HR_2_program">HR 2 program</option>
              <option value="HR_3_program">HR 3 program</option>
              <option value="HR_Pop">HR Pop</option>
              <option value="HR_Klasika"> HR Klasika</option>
              <option value="Radio_101_Live">Radio 101 Live</option>
              <option value="Radio_101_Rock">Radio 101 Rock</option>
              <option value="Radio_101_Soft_Sound">Radio 101 Soft Sound</option>
            <!-- <option value="Radio_Pula">Radio Pula</option>
              <option value="Radio_Osijek">Radio Osijek</option>-->
              <option value="Radio_Tvornica">Radio Tvornica</option>
              <option value="Radio_808">Radio 808</option>
              <option value="Radio_deejay_hr">Radio deejay.hr</option>
	<option value="1980s_90s_Lite_Hits">1980s_&_'90s_Lite_Hits</option>
            </select>
          </div>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="card text-white bg-primary">
          <div class="card-header">Što trenutno svira</div>
          <div class="card-body">
            <div class="song-info text-center">
              <div id="currentSong" class="lead custom-font-size text-white">Trenutno nema podataka</div>
              <div><img id="albumImage" src="" class="img-fluid album-border" style="padding-left: 10px; max-width: 150px;"></div>
              <div id="albumName" class="text-white"></div>
              <div id="releaseYear" class="text-white"></div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-md-5">
        <div class="card text-white bg-primary">
          <div class="card-header">Vremenska prognoza</div>
          <div class="card-body">
            <div id="podaci">
              <!-- Podaci o vremenu će se prikazati ovdje -->
            </div>
          <div>
        </div>
      </div>
 
    </div>
  </div>

    <div class="footer-container">
      <canvas id="visualizer" class="border"></canvas>
    </div>    
    <!-- Modal: O nama -->
    <div class="modal fade" id="aboutModal" tabindex="-1" aria-labelledby="aboutModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title black_text" id="aboutModalLabel">O nama</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body black_text">
            <p>Ovaj radio player napravljen je kao suradnja između korisnika Davora i ChatGPT-a. Svrha je testiranje i učenje izrade dinamičnih web stranica.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Zatvori</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal: O nama -->
    <div class="modal fade" id="changelogModal" tabindex="-1" aria-labelledby="changelogModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title black_text" id="changelogModalLabel">O nama</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body black_text">
            <p class="text_lijevo">
          <?php
            $filePath = 'changelog.txt';  // Putanja do vašeg TXT fajla
            if (file_exists($filePath)) {
              $fileContent = file_get_contents($filePath);
              echo nl2br($fileContent);  // nl2br za očuvanje novih linija u tekstu
            } else {
              echo 'Fajl nije pronađen!';
            }
          ?>
            </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Zatvori</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal: Kontakt -->
    <div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title black_text" id="contactModalLabel">Kontakt</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body black_text">
            <p><script src="js/mail.js"></script></p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Zatvori</button>
          </div>
        </div>
      </div>
    </div>

    <?php
    // Učitaj sadržaj datoteke
    $fileContent = file_get_contents('changelog.txt');
    
    // Regex za dohvaćanje prvog <strong> elementa
    preg_match('/<strong>(.*?)<\/strong>/', $fileContent, $matches);
    
    $version = $matches[1] ?? 'Verzija nije pronađena';
    
//    echo "Trenutna verzija: $version";
    ?>

    <!-- Footer -->
    <div class="footer-container">
      <footer>
<?php
echo "Trenutna verzija: $version" . "<br";
?>
        <p>&copy; 2024 Radio Player by ChatGPT i Davor, v<?php echo $version; ?>. Izrada skripte je testiranje ChatGPT-a s instrukcijama korisnika za pisanje koda.</p>
      </footer>
    </div>
  </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/streams.js"></script>
    <script src="js/songFetch.js"></script>
    <!--<script src="js/controls.js"></script>-->
    <script src="js/visualizer.js"></script>
    <script src="js/radio.js"></script>
    <script src="js/vrijeme.js"></script>
  </body>
</html>
