<?php
function getCurrentSong() {
  //$url = "http://185.155.227.16:8000/currentsong?sid=1";
  $url = "http://live.radiocrash.net:8000/currentsong?sid=1";

  // Postavite HTTP kontekst
  $context = stream_context_create([
    'http' => [
      'timeout' => 10 // Timeout u sekundama
    ]
  ]);

  // Dohvati sadržaj s URL-a
  $response = @file_get_contents($url, false, $context);

  if ($response === false) {
    return "Greška prilikom dohvaćanja podataka";
  }

  return $response;
}

// Dohvati trenutnu pjesmu
echo getCurrentSong();
?>
