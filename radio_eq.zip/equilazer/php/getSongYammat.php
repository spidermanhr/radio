<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function getCurrentSong() {
  $url = 'https://stream.yammat.fm/radio/8000/';

  // Dohvati HTML sadržaj
  $html = file_get_contents($url);

  if ($html === false) {
    return "Ne mogu dohvatiti sadržaj s URL-a.";
  }

  // Učitaj HTML u DOMDocument
  $dom = new DOMDocument();
  libxml_use_internal_errors(true); // Ignoriraj HTML greške
  $dom->loadHTML($html);
  libxml_clear_errors();

  // Pronađi sve td elemente s klasom "streamdata"
  $xpath = new DOMXPath($dom);
  $nodes = $xpath->query('//tr[td="Current Song:"]/td[@class="streamdata"]');

  // Provjeri postoji li takav element
  if ($nodes->length > 0) {
    return trim($nodes[0]->nodeValue);
  } else {
    return "Trenutna pjesma nije pronađena.";
  }
}

// Pozovi funkciju i ispiši rezultat
echo getCurrentSong();
?>
